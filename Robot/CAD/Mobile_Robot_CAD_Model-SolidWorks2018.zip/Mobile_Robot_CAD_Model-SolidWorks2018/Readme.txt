
- This CAD model is designed in SolidWorks 2018. SolidWorks 2018 or newer versions can be used to easily manipulate the CAD Model.

- Circuit diagram for "Circuit_Assembly.SLDASM" can be found at https://github.com/EWA-Mechatronics/ME462-Project/blob/master/Robot/robot-circuit-diagram.png

- Some parts include multiple configurations. Don't forget to check them.

- "bottom_contact_charger.SLDPRT" is not used in the assembly. This part can be used to prepare a charging dock for the robot.

- Some of the CAD Models used in this design are obtained from https://grabcad.com/